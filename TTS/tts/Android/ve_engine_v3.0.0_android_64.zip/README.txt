Vocalizer SDK for Android
Copyright by Nuance Communications, Inc.


USING THE VOCALIZER SDK IN YOUR ANDROID PROJECT

Copy the contents of the bin folder (including subdirectories) in <your project path>\libs

Your libs directory will then look something like this:

<your project path>\libs\vocalizerlib.jar
<your project path>\libs\armeabi\libNuanceVocalizer.so

From Eclipse, select Project > Properties > Java Build Path and click on the "Add External JARs" button.
Navigate to the libs folder of your project and select the vocalizerlib.jar file.

Hit OK. You're now ready to use the Vocalizer SDK in your Android Project!


DOCUMENTATION

Documentation for using the Vocalizer SDK for Android is located in the "doc" folder.




